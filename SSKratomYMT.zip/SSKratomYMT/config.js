// --- Runtime configuration ---
// Put your real endpoints here. These defaults come from your previous single-file app.
window.APP_CONFIG = {
  SHEET_URL: "https://docs.google.com/spreadsheets/d/11vhg37MbHRm53SSEHLsCI3EBXx5_meXVvlRuqhFteaY",
  HOOK_URL: "https://script.google.com/macros/s/AKfycbxXAaBlyCFRfdQa4jPk8YehSmXE07sn3tXg8kfdDGtDkMCSqRB4_DDIDiyit2tzDOSR/exec",
  PRICE_PER_BOTTLE: 40
};
